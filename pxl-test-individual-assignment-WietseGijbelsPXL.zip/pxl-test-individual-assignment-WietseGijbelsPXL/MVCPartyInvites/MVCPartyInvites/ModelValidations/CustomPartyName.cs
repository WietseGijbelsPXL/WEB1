﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MVCPartyInvites.ModelValidations
{
    public class CustomPartyName : Attribute, IModelValidator
    {
        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            var list = new List<ModelValidationResult>();
            if(context.Model != null && !context.Model.ToString().Contains("pxl"))
            {
                list.Add(new ModelValidationResult("", "Party name must contain 'pxl'!"));
            }
            return list;
        }
    }
}
