﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MVCPartyInvites.ModelValidations
{
    public class CustomDate : Attribute, IModelValidator
    {
        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            var dtm = DateTime.Now;
            var list = new List<ModelValidationResult>();
            if(context.Model != null && DateTime.TryParse(context.Model.ToString(), out dtm))
            {
                if(dtm > DateTime.Now)
                {
                    list.Add(new ModelValidationResult("", "Date of Birth cannot be in the future!"));
                }
            }
            else
            {
                list.Add(new ModelValidationResult("", "Invalid Date of Birth!"));
            }
            return list;
        }
    }

}
