﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MVCPartyInvites.ModelValidations
{
    public class CustomText : Attribute, IModelValidator
    {
        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            var list = new List<ModelValidationResult>();
            if (context.Model != null && context.Model.ToString().Length < 2)
            {
                list.Add(new ModelValidationResult("", "Text must have at least 2 characters!"));

            }
            return list;
        }
    }
}
