﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MVCPartyInvites.ModelValidations
{
    public class NumberOfGuests : Attribute, IModelValidator
    {
        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            var list = new List<ModelValidationResult>();
            if (context.Model != null && (int.Parse(context.Model.ToString()) > 4 || int.Parse(context.Model.ToString()) < 1))
            {
                list.Add(new ModelValidationResult("", "Number of guests must be between 1 and 4!"));
            }
            return list;
        }
    }
}
