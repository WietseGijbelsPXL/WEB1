﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MVCPartyInvites.ModelValidations
{
    public class CustomPartyDate : Attribute, IModelValidator
    {
        public IEnumerable<ModelValidationResult> Validate(ModelValidationContext context)
        {
            var dtm = DateTime.Now;
            var list = new List<ModelValidationResult>();
            if (context.Model != null && DateTime.TryParse(context.Model.ToString(), out dtm))
            {
                if (dtm < DateTime.Now)
                {
                    list.Add(new ModelValidationResult("", "Party date must be in the future!"));
                }
            }
            return list;
        }
    }
}
