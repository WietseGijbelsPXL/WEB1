﻿using MVCPartyInvites.Models;
using MVCPartyInvites.ViewModels;

namespace MVCPartyInvites.Data
{
    public static class LocalData
    {
        public static List<Guest> GuestList = new List<Guest>();
        public static List<Party> PartyList = new List<Party>();

        public static List<PartyGuest> PartyGuestList = new List<PartyGuest>();
        public static void AddGuest(GuestViewModel guest)
        {
            var newGuest = ConvertGuestFromViewModel(guest);
            newGuest.IsPresent = true;
            GuestList.Add(newGuest);
        }
        public static void UpdateGuest(GuestUpdateViewModel vm)
        {
            var guest = GuestList.FirstOrDefault(x => x.Id == vm.Id);
            if (guest != null)
            {
                guest.IsPresent = false;
            }
        }
        private static Guest ConvertGuestFromViewModel(GuestViewModel vm)
        {
            var id = 1;
            if (GuestList.Count > 0)
            {
                id = GuestList.Max(x => x.Id);
                id++;
            }
            Guest guest = new Guest();
            guest.Id = id;
            guest.Name = vm.Name;
            guest.Email = vm.Email;
            guest.Phone = vm.Phone;
            return guest;
        }

        public static void AddParty(PartyViewModel party)
        {
            var id = 1;
            if (PartyList.Count > 0)
            {
                id = PartyList.Max(x => x.Id);
                id++;
            }
            Party newParty = new Party();
            newParty.Id = id;
            newParty.PartyName = party.PartyName;
            newParty.PartyDate = party.PartyDate;
            PartyList.Add(newParty);
        }

        public static void UpdateParty(PartyViewModel vm)
        {
            var party = PartyList.FirstOrDefault(x => x.Id == vm.Id);
            if (party != null)
            {
                party.PartyName = vm.PartyName;
                party.PartyDate = vm.PartyDate;
            }
        }

        public static void AddPartyGuest(PartyGuestViewModel vm)
        {
            var id = 1;
            if (PartyList.Count > 0)
            {
                id = PartyList.Max(x => x.Id);
                id++;
            }
            var partyGuest = new PartyGuest();
            partyGuest.Id = id;
            partyGuest.PartyId = vm.PartyId;
            partyGuest.GuestId = vm.GuestId;
            partyGuest.Party = PartyList.FirstOrDefault(x => x.Id == vm.PartyId);
            partyGuest.Guest = GuestList.FirstOrDefault(x => x.Id == vm.GuestId);
            partyGuest.NumberOfGuests = vm.NumberOfGuests;
            PartyGuestList.Add(partyGuest);
        }

        public static void UpdatePartyGuest(PartyGuestViewModel vm)
        {
            var partyGuest = PartyGuestList.FirstOrDefault(x => x.Id == vm.Id);
            if (partyGuest != null)
            {
                partyGuest.Id = vm.Id;
                partyGuest.PartyId = vm.PartyId;
                partyGuest.GuestId = vm.GuestId;
                partyGuest.NumberOfGuests = vm.NumberOfGuests;
            }
        }


        public static void SeedData()
        {
            var p = new PartyViewModel();
            p.PartyName = "Pxl party 01";
            p.PartyDate = DateTime.Now.AddDays(7);
            AddParty(p);
            p = new PartyViewModel();
            p.PartyName = "Pxl party 02";
            p.PartyDate = DateTime.Now.AddDays(14);
            AddParty(p);
            var g = new GuestViewModel();
            g.Name = "Kristof Palmaers";
            g.BirthDate = new DateTime(2000, 1, 1);
            g.Phone = "0499/123456";
            g.Email = "kristof.palmaers@pxl.be";
            AddGuest(g);
            g = new GuestViewModel();
            g.Name = "StudentFirstName StudentLastName";
            g.BirthDate = new DateTime(2001, 1, 1);
            g.Phone = "0488/123456";
            g.Email = "first.last@pxl.be";
            AddGuest(g);

            var pg = new PartyGuestViewModel();
            pg.PartyId = 1;
            pg.GuestId = 1;
            pg.NumberOfGuests = 3;
            AddPartyGuest(pg);
        }
    }
}
