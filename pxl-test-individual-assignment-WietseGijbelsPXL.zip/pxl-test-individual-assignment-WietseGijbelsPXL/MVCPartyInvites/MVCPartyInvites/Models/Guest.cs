﻿namespace MVCPartyInvites.Models
{
    public class Guest
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public bool IsPresent { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
