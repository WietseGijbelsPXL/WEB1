﻿namespace MVCPartyInvites.Models
{
    public class PartyGuest
    {
        public int Id { get; set; }
        public int PartyId { get; set; }
        public Party? Party { get; set; }
        public int GuestId { get; set; }
        public Guest? Guest { get; set; }
        public int NumberOfGuests { get; set; }
    }
}
