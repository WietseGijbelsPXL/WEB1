﻿namespace MVCPartyInvites.Models
{
    public class Party
    {
        public int Id { get; set; }
        public string PartyName { get; set; }
        public DateTime PartyDate { get; set; }
    }
}
