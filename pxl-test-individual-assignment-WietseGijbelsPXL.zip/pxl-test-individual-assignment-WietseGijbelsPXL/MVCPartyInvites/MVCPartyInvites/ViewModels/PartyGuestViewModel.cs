﻿using MVCPartyInvites.ModelValidations;
using System.ComponentModel.DataAnnotations;

namespace MVCPartyInvites.ViewModels
{
    public class PartyGuestViewModel
    {
        public int Id { get; set; }
        [Required]
        public int PartyId { get; set; }
        [Required]
        public int GuestId { get; set; }
        [Required]
        [NumberOfGuests]
        public int NumberOfGuests { get; set; }
    }
}
