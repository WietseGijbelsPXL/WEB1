﻿namespace MVCPartyInvites.ViewModels
{
    public class EditPartyViewModel: PartyViewModel
    {
        public int Id { get; set; }
    }
}
