﻿using MVCPartyInvites.ModelValidations;

namespace MVCPartyInvites.ViewModels
{
    public class PartyViewModel
    {
        public int Id { get; set; }
        [CustomPartyName]
        public string PartyName { get; set; }
        [CustomPartyDate]
        public DateTime PartyDate { get; set; }
    }
}
