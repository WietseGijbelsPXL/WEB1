﻿namespace MVCPartyInvites.ViewModels
{
    public class GuestUpdateViewModel
    {
        public int Id { get; set; }
    }
}
