﻿using System.ComponentModel.DataAnnotations;
using MVCPartyInvites.ModelValidations;
namespace MVCPartyInvites.ViewModels
{
    public class GuestViewModel
    {
        [CustomText]
        public string Name { get; set; } = string.Empty;
        [Required(ErrorMessage = "Vul je telefoonnumer in!")]
        public string Phone { get; set; } = string.Empty;
        [Required(ErrorMessage = "Vul je email in!")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
        [CustomDate]
        public DateTime BirthDate { get; set; } = DateTime.Now;
    }
}
