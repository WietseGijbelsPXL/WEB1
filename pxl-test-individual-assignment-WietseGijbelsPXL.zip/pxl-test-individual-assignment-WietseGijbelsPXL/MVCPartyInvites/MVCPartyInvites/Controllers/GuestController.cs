﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVCPartyInvites.Data;
using MVCPartyInvites.ViewModels;

namespace MVCPartyInvites.Controllers
{
    public class GuestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            GuestViewModel guest = new GuestViewModel();
            return View(guest);
        }

        [HttpPost]
        public IActionResult GuestReservation(GuestViewModel guest)
        {
            if (ModelState.IsValid)
            {
                LocalData.AddGuest(guest);
                return RedirectToAction("Index", "Home");
            }
            return View("Create", guest);
        }

        public IActionResult Update()
        {
            var list = LocalData.GuestList.Where(x => x.IsPresent == true).ToList();
            ViewBag.Combobox = new SelectList(list, "Id", "Name");
            return View(new GuestUpdateViewModel());
        }

        [HttpPost]
        public IActionResult Update(GuestUpdateViewModel vm)
        {
            LocalData.UpdateGuest(vm);
            return RedirectToAction("Index", "Home");
        }
    }
}
