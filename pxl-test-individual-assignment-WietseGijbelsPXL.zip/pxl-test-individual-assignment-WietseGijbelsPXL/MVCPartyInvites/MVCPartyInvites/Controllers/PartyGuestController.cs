﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVCPartyInvites.Data;
using MVCPartyInvites.ViewModels;

namespace MVCPartyInvites.Controllers
{
    public class PartyGuestController : Controller
    {
        public IActionResult Index()
        {
            return View(LocalData.PartyGuestList);
        }

        public IActionResult Create()
        {
            ViewBag.Parties = new SelectList(LocalData.PartyList, "Id", "PartyName");
            ViewBag.Guests = new SelectList(LocalData.GuestList, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(PartyGuestViewModel vm)
        {
            if (ModelState.IsValid)
            {
                LocalData.AddPartyGuest(vm);
                return RedirectToAction("Index");
            }
            ViewBag.Parties = new SelectList(LocalData.PartyList, "Id", "PartyName");
            ViewBag.Guests = new SelectList(LocalData.GuestList, "Id", "Name");
            return View(vm);
        }

        public IActionResult Edit(int id)
        {
            ViewBag.Parties = new SelectList(LocalData.PartyList, "Id", "PartyName");
            ViewBag.Guests = new SelectList(LocalData.GuestList, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Edit(PartyGuestViewModel vm)
        {
            if (ModelState.IsValid)
            {
                LocalData.UpdatePartyGuest(vm);
                return RedirectToAction("Index");
            }
            ViewBag.Parties = new SelectList(LocalData.PartyList, "Id", "PartyName");
            ViewBag.Guests = new SelectList(LocalData.GuestList, "Id", "Name");
            return View(vm);
        }
    }
}
