﻿using Microsoft.AspNetCore.Mvc;
using MVCPartyInvites.Data;
using MVCPartyInvites.ViewModels;

namespace MVCPartyInvites.Controllers
{
    public class PartyController : Controller
    {
        public IActionResult Index()
        {
            return View(LocalData.PartyList);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(PartyViewModel party)
        {
            if (ModelState.IsValid)
            {
                LocalData.AddParty(party);
                return RedirectToAction("Index");
            }
            return View(party);
        }

        public IActionResult Details(int id)
        {
            var party = LocalData.PartyList.Where(x => x.Id == id).FirstOrDefault();
            if (party != null)
            {
                return View(party);
            }
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            return View();
        }

        [HttpPost]
        public IActionResult Edit(EditPartyViewModel party)
        {
            if(ModelState.IsValid)
            {
                LocalData.UpdateParty(party);
                return RedirectToAction("Index");
            }
            return View(party);
        }
    }
}
