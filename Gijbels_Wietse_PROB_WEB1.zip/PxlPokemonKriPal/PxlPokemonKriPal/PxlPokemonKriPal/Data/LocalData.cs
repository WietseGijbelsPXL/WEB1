﻿using PxlPokemonKriPal.Models;
using PxlPokemonKriPal.ViewModel;

namespace PxlPokemonKriPal.Data
{
    public static class LocalData
    {
        public static List<Pokemon> PokemonList { get; set; }
        public static List<PokemonTrainer> TrainerList { get; set; }

        public static void InitializeData()
        {
            PokemonList = new List<Pokemon>
            {
                new Pokemon { Id = 1, Name = "Pikachu", PokemonType = "Fire" },
                new Pokemon { Id = 2, Name = "Bulbasaur", PokemonType = "Grass" },
            };
            TrainerList = new List<PokemonTrainer>
            {
                new PokemonTrainer { Id = 1, TrainerName = "Wietse Gijbels" },
            };
        }

        public static void AddPokemon(PokemonViewModel pokemon)
        {
            Pokemon p = new Pokemon()
            {
                Id = PokemonList.Max(p => p.Id) + 1,
                Name = pokemon.Name,
                PokemonType = pokemon.PokemonType
            };
            PokemonList.Add(p);
        }
    }
}
