using Microsoft.AspNetCore.Mvc;
using PxlPokemonKriPal.Data;
using PxlPokemonKriPal.Models;
using System.Diagnostics;

namespace PxlPokemonKriPal.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.TrainerName = LocalData.TrainerList.FirstOrDefault()?.TrainerName;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
