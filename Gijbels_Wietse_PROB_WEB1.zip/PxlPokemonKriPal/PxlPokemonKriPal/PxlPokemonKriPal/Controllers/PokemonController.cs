﻿using Microsoft.AspNetCore.Mvc;
using PxlPokemonKriPal.Data;
using PxlPokemonKriPal.ViewModel;

namespace PxlPokemonKriPal.Controllers
{
    public class PokemonController : Controller
    {
        public IActionResult Index()
        {
            return View(LocalData.PokemonList);
        }

        public IActionResult Create() 
        {
            return View("Create");
        }

        [HttpPost]
        public IActionResult CreatePokemon(PokemonViewModel pokemon)
        {
            LocalData.AddPokemon(pokemon);
            return RedirectToAction("Index");
        }
    }
}
