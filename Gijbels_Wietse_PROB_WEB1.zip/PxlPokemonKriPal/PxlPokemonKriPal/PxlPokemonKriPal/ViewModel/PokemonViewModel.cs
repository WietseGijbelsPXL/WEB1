﻿namespace PxlPokemonKriPal.ViewModel
{
    public class PokemonViewModel
    {
        public string Name { get; set; }
        public string PokemonType { get; set; }
    }
}
