﻿namespace PxlPokemonKriPal.Models
{
    public class PokemonTrainer
    {
        public int Id { get; set; }
        public string TrainerName { get; set; }
    }
}
